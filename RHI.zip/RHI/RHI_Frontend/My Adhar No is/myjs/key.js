$(function() {
    $("input").keyboard({
      
      enterNavigation: true,
      maxLength: 1,
      layout: 'num',
      initialFocus: false,
      autoAccept: true,
      usePreview: false,
      change: function(e, keyboard, el) {
        var len = keyboard.$el.hasClass("last") ? 1: 1,
          key = keyboard.last.keyPress;
        // don't switch if user pressed arrow keys
        if (
          keyboard.$el.val().length >= len &&
          !( key === 37 || key === 39 )
        ) {
          // switchInput( goToNext, isAccepted );
          keyboard.switchInput(true, true);
        } else if (keyboard.$el.val() === "" && keyboard.last.key === "bksp") {
          // go to previous if user hits backspace on an empty input
          keyboard.switchInput(false, true);
        }
      }
    });
  });