function getAdharNO()
{

var AdharNo= document.getElementById('textField').value.substring(0,4)+ document.getElementById('textField1').value.substring(0,4)+ document.getElementById('textField2').value.substring(0,4);
console.log("Entered Addhar no is:"+AdharNo);
}