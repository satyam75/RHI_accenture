

function addNumber(element){
  
  var temp=MaxLenT1();
  var temp1=MaxLenT2();
  var temp2= MaxLenT3();
 if(temp==true)
  {
  
  var currentPos = getCaret(textField);
  if(document.getElementById('textField').value.length<4)
  {
  document.getElementById('textField').value = document.getElementById('textField').value.substring(0,currentPos)+element.value+document.getElementById('textField').value.substring(currentPos,document.getElementById('textField').value.length);
  resetCursor(textField, currentPos+1);
  console.log(document.getElementById('textField').value);
 //break;
  }
  }

 

if(this.temp1==true)
  {
    
    var currentPos = getCaret(textField1);
    if(document.getElementById('textField1').value.length<4)
    {
    document.getElementById('textField1').value = document.getElementById('textField1').value.substring(0,currentPos)+element.value+document.getElementById('textField1').value.substring(currentPos,document.getElementById('textField1').value.length);
    resetCursor(textField1, currentPos+1);
    console.log(document.getElementById('textField1').value);
   }
  
   // this.temp1=MaxLenT2();
 // break;
  }
  

 

 if(this.temp2==true)
  {
  var currentPos = getCaret(textField2);
  if(document.getElementById('textField2').value.length<4)
  {
  document.getElementById('textField2').value = document.getElementById('textField2').value.substring(0,currentPos)+element.value+document.getElementById('textField2').value.substring(currentPos,document.getElementById('textField2').value.length);
  resetCursor(textField2, currentPos+1);
  console.log(document.getElementById('textField2').value);  
 }
  //temp=element.value;
 //break;
  }
  
}



 function getCaret(el) {
    if (el.selectionStart) {
        return el.selectionStart;
    } else if (document.selection) {
        el.focus();

        var r = document.selection.createRange();
        if (r == null) {
            return 0;
        }

        var re = el.createTextRange(),
            rc = re.duplicate();
        re.moveToBookmark(r.getBookmark());
        rc.setEndPoint('EndToStart', re);

        return rc.text.length;
    }
    return 0;
}

function resetCursor(txtElement, currentPos) { 
    if (txtElement.setSelectionRange) { 
        txtElement.focus(); 
        txtElement.setSelectionRange(currentPos, currentPos); 
    } else if (txtElement.createTextRange) { 
        var range = txtElement.createTextRange();  
        range.moveStart('character', currentPos); 
        range.select(); 
    } 
}

var focusedArea=null;

function ActiveElem(){
   
  this.focusedArea=document.activeElement.id;
}

function MaxLenT1()
{
 if(document.getElementById('textField').value.length>3&&document.getElementById('textField1').value.length==0&&document.getElementById('textField2').value.length==0){
this.temp1=true;
console.log("m1");

 //document.getElementById('textField1').focus();
 return false;
 }
else{
 
   return true;
}
}

function MaxLenT2()
{
 if(document.getElementById('textField').value.length>3&&document.getElementById('textField1').value.length>3&&document.getElementById('textField2').value.length==0){
 this.temp2=true;
 console.log("m2");
 //document.getElementById('textField1').focus();
 return false;
 }
 else{
  
  return true;
 }
}

function MaxLenT3()
{
 if(document.getElementById('textField2').value.length==4&&document.getElementById('textField1').value.length==4&&document.getElementById('textField').value.length==4){
   return false;
 }
 else{
   return true;
 }
}

function clearNumber() {
console.log(focusedArea);
 if(focusedArea=='textField'){
    var textField = document.getElementById('textField');
    var currentPos = getCaret(textField);    
    var text = document.getElementById('textField').value;

    var backSpace = text.substr(0, currentPos-1)+text.substr(currentPos, text.length);

    document.getElementById('textField').value=(backSpace);
    
    resetCursor(textField, currentPos-1);
  }

  if(focusedArea=='textField1'){
    var textField = document.getElementById('textField1');
    var currentPos = getCaret(textField);    
    var text = document.getElementById('textField1').value;
  
    var backSpace = text.substr(0, currentPos-1)+text.substr(currentPos, text.length);
  
    document.getElementById('textField1').value=(backSpace);
    
    resetCursor(textField, currentPos-1);
  }

  if(focusedArea=='textField2'){
    var textField = document.getElementById('textField2');
    var currentPos = getCaret(textField);    
    var text = document.getElementById('textField2').value;

    var backSpace = text.substr(0, currentPos-1)+text.substr(currentPos, text.length);

    document.getElementById('textField2').value=(backSpace);
    
    resetCursor(textField, currentPos-1);
  }
}




