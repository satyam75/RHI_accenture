function getAdharNO()
{

var otp= document.getElementById('textField').value;
console.log("Entered OTP is:"+otp);
}