function addNumber(element){
 while( document.getElementById('textField').value.length<4)
  {
   var currentPos = getCaret(textField); 
  document.getElementById('textField').value = document.getElementById('textField').value.substring(0,currentPos)+element.value+document.getElementById('textField').value.substring(currentPos,document.getElementById('textField').value.length);
  resetCursor(textField, currentPos+1);
  //element.value='';
  
  break;
 
  }
}

function getCaret(el) {
    if (el.selectionStart) {
        return el.selectionStart;
    } else if (document.selection) {
        el.focus();

        var r = document.selection.createRange();
        if (r == null) {
            return 0;
        }

        var re = el.createTextRange(),
            rc = re.duplicate();
        re.moveToBookmark(r.getBookmark());
        rc.setEndPoint('EndToStart', re);

        return rc.text.length;
    }
    return 0;
}

function resetCursor(txtElement, currentPos) { 
    if (txtElement.setSelectionRange) { 
        txtElement.focus(); 
        txtElement.setSelectionRange(currentPos, currentPos); 
    } else if (txtElement.createTextRange) { 
        var range = txtElement.createTextRange();  
        range.moveStart('character', currentPos); 
        range.select(); 
    } 
}
function clearNumber() {

 
    var textField = document.getElementById('textField');
    var currentPos = getCaret(textField);    
    var text = document.getElementById('textField').value;

    var backSpace = text.substr(0, currentPos-1)+text.substr(currentPos, text.length);

    document.getElementById('textField').value=(backSpace);
    
    resetCursor(textField, currentPos-1);
  }


